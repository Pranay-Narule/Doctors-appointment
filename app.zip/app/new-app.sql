-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2021 at 12:48 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doc_app_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `new-app`
--

CREATE TABLE `new-app` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(10) NOT NULL,
  `dob` date NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `app-date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `report` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `new-app`
--

INSERT INTO `new-app` (`id`, `name`, `age`, `dob`, `blood_group`, `address`, `mobile`, `email`, `app-date`, `time`, `report`) VALUES
(27, 'Pranay Narule', 25, '1996-07-22', '', 'abc', 8421840494, 'dedicated.and.designated@gmail', '2021-10-01', '01PM', 'status.jpg'),
(28, 'ABC XYZ', 10, '2011-01-30', 'O+', 'zaxaxsw', 9865321470, 'pranaynarule564@gmail.com', '2021-10-01', '10AM', 'background.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `new-app`
--
ALTER TABLE `new-app`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `new-app`
--
ALTER TABLE `new-app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
